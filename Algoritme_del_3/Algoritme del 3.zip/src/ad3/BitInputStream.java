package ad3;

import java.io.IOException;
import java.io.InputStream;

/**
 * Methods to transform an input byte stream into a stream of
 * bits.
 */

public class BitInputStream {

    // Underlying byte stream to read from.
    private InputStream input;

    // Buffer of up to 8 bits from the most recently read byte of the
    // underlying byte input stream. Is an int in the range 0 to 255
    // if bits are available, or is -1 if the end of stream is
    // reached.
    private int nextBits;
    
    // Always between 0 and 8, inclusive.
    private int numBitsRemaining;

    private boolean isEndOfStream;


    // Creates a bit input stream based on the given byte input stream.
    public BitInputStream(InputStream in) {
	if (in == null)
	    throw new NullPointerException("No input stream given");
	input = in;
	numBitsRemaining = 0;
	isEndOfStream = false;
    }


    // Reads a bit from the stream. Returns 0 or 1 if a bit is
    // available, or -1 if the end of stream is reached. The end of
    // stream always occurs on a byte boundary.
    public int readBit() throws IOException {
	if (isEndOfStream)
	    return -1;
	if (numBitsRemaining == 0) {
	    nextBits = input.read();
	    if (nextBits == -1) {
		isEndOfStream = true;
		return -1;
	    }
	    numBitsRemaining = 8;
	}
	numBitsRemaining--;
	return (nextBits >>> numBitsRemaining) & 1;
    }
    
    // Gets array with count of how many times different characters occurs.
    public PQHeap readBits() throws IOException 
    {
        PQHeap lst = new PQHeap(256);
        int[] arr = new int[256];
	while(!isEndOfStream)
        {
            if (numBitsRemaining == 0) 
            {
                nextBits = input.read();
                if (nextBits == -1) 
                {
                    isEndOfStream = true;
                    break;
                }
                arr[nextBits]++;
                numBitsRemaining = 8;
            }
            numBitsRemaining--;
        }
        int c = 0;
        for (int i : arr)
        {
            if(i > 0)
            {
                lst.insert(new Element(c, new Node(c, i)));
            }
            c++;
        }
        
	return lst;
    }
    
    public String getBitCode(Node n) throws IOException 
    {
	String str = "";
	while(!isEndOfStream)
        {
            if (numBitsRemaining == 0) 
            {
                nextBits = input.read();
                
                if (nextBits == -1) 
                {
                    isEndOfStream = true;
                    break;
                }
                
                str += getBitCodePart(nextBits, n, 2);
                numBitsRemaining = 8;
            }
            numBitsRemaining--;
        }
        
        return str;
    }
    
    private String getBitCodePart(int key, Node n, int direction)
    {
        int k = key;
        Node x = n;
        String s = "";
        
        if(x == null) 
        {
            return s + "";
        }
        
        if(x.leftChild != null) 
        {
            s += getBitCodePart(k, x.leftChild, 0);
        }
        
        if(x.rightChild != null) 
        {
            s += getBitCodePart(k, x.rightChild, 1);
        }
        
        if(direction==2 || "".equals(s) && x.key != k)
        {
            return s;
        }
        else
        {
            return direction + s;
        }
    }

    // Reads an int from the stream. Throws IOException if 32 bits are
    // not available.
    public int readInt() throws IOException {
	int output = 0;
	int nextBit;
	int bitsAdded = 0;
	while(bitsAdded < 32){
	    nextBit = readBit();
	    if (nextBit == -1)
		throw new IOException("Not enough bits while trying to read int");
	    output = output << 1 | nextBit;
	    bitsAdded++;
	}
	return output;
    }


    // Closes this stream and the underlying InputStream.
    public void close() throws IOException {
	input.close();
    }

}
