package ad3;

public class Element {
	public int key;
	public Object data;

	public Element(int i, Object o) {
		this.key = i;
		this.data = o;
	}
}
