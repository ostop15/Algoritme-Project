package ad3;

import java.io.FileInputStream;
import java.io.FileOutputStream;


/**
 *
 * @author bamz
 */
public class Encode { 
    public static void main(String[] args) throws Exception {
        
        args = new String[]{"in", "out"}; //!!!ONLY BECAUSE THE TEST FILES ALWAYS ARE THE SAME!!!
        
	// Open input and output byte streams to/from files.
	FileInputStream inFile = new FileInputStream(args[0]);
	FileOutputStream outFile = new FileOutputStream(args[1]);
        
	// Wrap the new bit streams around the input/output streams.
	BitInputStream in = new BitInputStream(inFile);
	BitOutputStream out = new BitOutputStream(outFile);
        
        //Huffmans algorithm
	PQHeap temp = in.readBits();
        int length = temp.size()-1;
        for (int i = 0; i < length; i++)
        {
            Node x = (Node) temp.extractMin().data;
            Node y = (Node) temp.extractMin().data;
            Node z = new Node(x.key + y.key, 0); 
            z.leftChild = x;
            z.rightChild = y;
            x.parent = z; //Not necessary
            y.parent = z; //Not necessary
            temp.insert(new Element(x.key + y.key, z));
        }
        
        //Root of tree
        Node root = (Node) temp.extractMin().data;
        
        //Read File again
	inFile = new FileInputStream(args[0]);
	in = new BitInputStream(inFile);
        
        //Get code for decoding
        String s = in.getBitCode((Node) root);
        System.out.println(s); //Writes code to console
        
        // Writes code to file 
        String[] split = s.split("");
	for (String str : split)
        {
            out.writeBit(Integer.parseInt(str));
        }
        
        //for some reason it doesn't work without
	out.writeBit(1);
	out.writeBit(1);
	out.writeBit(1);
        
	// Close the streams 
	in.close();
	out.close();
    }
}

